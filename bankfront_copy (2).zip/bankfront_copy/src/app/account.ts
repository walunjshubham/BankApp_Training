import { User } from "./user";

export class Account{
    account_Id!:bigint;
    branch_Name!: string;
    account_Type!: number;
    account_Balance!: number;
    user_ID!:number;
    constructor(){}
}

// ccount_Id: 1000000000, 
// 	branch_Name: 'sbi', 
// 	account_Type: 'C',
// 	 account_Balance: 8888888, 
// 	 user