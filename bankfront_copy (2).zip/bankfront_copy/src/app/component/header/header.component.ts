import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { User } from 'src/app/user';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
user=new User();
  constructor(private route:Router,private toaster:ToastrService) { }

  ngOnInit(): void {
    let newObject:any = window.localStorage.getItem("user");
     console.log("user get by local storage"+JSON.parse(newObject));
    this.user=JSON.parse(newObject)
  }
  logOut(){
   
    window.localStorage.removeItem("user")
    window.localStorage.clear()
    window.location.reload()
   
    this.route.navigate(['user/signin'])
    this.toaster.info("You have been logged out")


  }

}
