import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgserviceService } from 'src/app/ngservice.service';
import { User } from 'src/app/user';
import {Location} from '@angular/common';

@Component({
  selector: 'app-list-of-accounts',
  templateUrl: './list-of-accounts.component.html',
  styleUrls: ['./list-of-accounts.component.css']
})
export class ListOfAccountsComponent implements OnInit {
  userObj=new User()
  selectedId:any;
  accountData:any=[]
  constructor(private router:ActivatedRoute,private _service:NgserviceService,
    private routing:Router,private location:Location) { }

  ngOnInit(): void {
    // let obj:any=window.localStorage.getItem("user");
    // this.userObj=JSON.parse(obj);
    // this.selectedId=this.userObj.user_ID


    this.router.paramMap.subscribe(
      paramMap=>{this.selectedId=paramMap.get('userId')}
    )
    console.log("user id in list of account="+this.selectedId);

    //get list of accounts by userID

      this._service.getAccountListByUserID(this.selectedId).subscribe(
        data=>{this.accountData=data;
        console.log(data)},
      //  error=>{console.log("error occured while fetching account data")}
      )
      
  }//end of ngOnIt

  goToEditAccount(accountId:any){
    console.log("account id from list of account compo"+accountId)
    this.routing.navigate(['account/editAccount',accountId]);
    //this.routing.navigate(['/account/editAccount',accountId])
    // this._service.updateAccountById(accountId).subscribe(
    //   data=>console.log("account updated succesfulyy"),
    //   error=>console.log("Account not updated suceesfully")
    // )
    
  }

  goToDeleteAccount(accountId:number){
    this._service.deleteAccountById(accountId).subscribe(
      data=>console.log("account deleted succesfulyy"),
      error=>console.log("Account not deleted")
    )
    location.reload();
  }

  goToBack(){
   // this.location.back();
   this.routing.navigate(['user/listOfUsers']);
  }

}
