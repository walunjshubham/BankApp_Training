import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
user=new User();
  constructor() { }

  ngOnInit(): void {
    let temp:any=window.localStorage.getItem("user");
    this.user=JSON.parse(temp);

  }

}
