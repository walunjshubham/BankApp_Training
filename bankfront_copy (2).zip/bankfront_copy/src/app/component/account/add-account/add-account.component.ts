import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Account } from 'src/app/account';
import { NgserviceService } from 'src/app/ngservice.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {
account=new Account();
user=new User();
id:any;
  constructor(private _service:NgserviceService,private route:Router,private routeElements:ActivatedRoute) { }

  ngOnInit(): void {

  let ls:any=window.localStorage.getItem("user");
  this.user=JSON.parse(ls);

  if(this.user==null){
    this.routeElements.paramMap.subscribe(
      paramMap=>{this.id=paramMap.get('user_ID')}
    )
    this.account.user_ID=this.id;
  }
  else
    this.account.user_ID=this.user.user_ID;
  }

  addAccountFormSubmit(addAccountForm:any){
    console.log(this.account)
    this._service.addAccount(this.account).subscribe(
      data=>{console.log(data+"account added successfully")},
     // error=>{console.log(error+"account not added successfully")}
    )
      this.route.navigate(['account/listOfAccounts/'+this.user.user_ID])

  }

  goToBack(){
    // this.location.back();
    this.route.navigate(['user/listOfUsers']);
   }
}
