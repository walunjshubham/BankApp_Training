import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Account } from 'src/app/account';
import { NgserviceService } from 'src/app/ngservice.service';
import { User } from 'src/app/user';
import {Location} from '@angular/common';

@Component({
  selector: 'app-edit-account',
  templateUrl: './edit-account.component.html',
  styleUrls: ['./edit-account.component.css']
})
export class EditAccountComponent implements OnInit {
  selectId:any;
  account=new Account();
  user=new User();

  constructor(private routing:Router,private routs:ActivatedRoute,
    private _service:NgserviceService,private location:Location) {
    console.log("account for edit"+this.selectId)
   }

  ngOnInit(): void {
      this.routs.paramMap.subscribe(paramMap=>{
      this.selectId=paramMap.get('accountId');
      console.log(this.selectId);
    })

    //find user by id 
    this._service.getAccountById(this.selectId).subscribe(
      data=>{this.account=data;
        console.log(data)
      } )
  
  }


  editAccountFormSubmit(editAccountForm:any){
    this._service.updateAccountById(this.selectId,this.account).subscribe(
      data=>{console.log("account updated successfully");
    },
      error=>{console.log("account not updated")}
    )
    //this.routing.navigate(['..']);
    window.location.reload()
   this.location.back();
    
  }
}
