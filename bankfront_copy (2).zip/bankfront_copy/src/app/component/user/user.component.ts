import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
user=new User();

  constructor() { }

  ngOnInit(): void {
    let newObj:any=window.localStorage.getItem("user");
    this.user=JSON.parse(newObj);
  }

}
