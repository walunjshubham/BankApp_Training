import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgserviceService } from 'src/app/ngservice.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-list-of-users',
  templateUrl: './list-of-users.component.html',
  styleUrls: ['./list-of-users.component.css']
})
export class ListOfUsersComponent implements OnInit {
usersList:any=[]
 otherUser=new User()
 userObj=new User();
 userId:any;

  constructor(private _service:NgserviceService,
    private router:Router,private toaster:ToastrService) { 
   this._service.getListOfUsers().subscribe(
    data=>{
      this.usersList=data;
     console.log(this.usersList)
    }
   )
   console.log("list of users : "+this.usersList)
 
  }

  ngOnInit(): void {
  

    let newObject:any = window.localStorage.getItem("user");
     console.log("user get by local storage"+JSON.parse(newObject));
    this.userObj=JSON.parse(newObject)
    this.userId=this.userObj.user_ID
    
    if(this.userId===null){
      this.router.navigate(['user/signin']);
    }
    
    else{
    this._service.getListOfUsers().subscribe(
      data=>{
        //this.usersList=data;
        this.usersList=data;

        console.log("users fetched successfully "+data)
        },
      error=>console.log("some error occured") 
    )
      }

  }

  goToEditUser(id:number){
    if(id===this.userObj.user_ID){
    this.router.navigate(['user/editUser',id]);
    
    }
    else
    this.toaster.error("you have to login with this user first")
    //alert("you have to login with this user first")
  }

  goToViewAccount(userId:number){
    if(userId===this.userObj.user_ID)
    this.router.navigate(['/account/listOfAccounts',userId])
    else
    this.toaster.error("You have to login with this user first")
    //alert("you have to login with this user first")

  }

  goToDeleteUser(id:number){
    if(id===this.userObj.user_ID){
      this._service.deleteUserById(id).subscribe(
        data=>{console.log("User deleted successfully")},
        error=>{console.log("user not deleted")}
      )
      location.reload();
      //this.router.navigate(['user/listOfUsers'])
    }
    else{
      this.toaster.error("You have to login with this user first")
    //alert("you have to login with this user first")
    }

  }

  addAccount(user_ID:number){
    if(user_ID===this.userObj.user_ID)
    this.router.navigate(['/account/addAccount',user_ID])
    else
    this.toaster.error("You have to login with this user first")
    //alert("you have to login with this user first")    
  }
}
// <a href="#" class="btn btn-primary active" aria-current="page"
//          routerLink="addAccount"routerLinkActive="active" >Add Account</a>