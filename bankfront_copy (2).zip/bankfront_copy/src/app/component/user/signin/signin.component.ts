import { Component, OnInit } from '@angular/core';
import { Router, TitleStrategy } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { NgserviceService } from 'src/app/ngservice.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
user=new User();
//check:boolean=false;
  constructor(private _service:NgserviceService,
    private route:Router,private toaster:ToastrService) { }

  ngOnInit(): void {
  }

  verifyUserFormSubmit(verifyUserForm:any){

    console.log("inside signin"+this.user.email_ID+ " " +this.user.password)
    this._service.loginCheck(this.user).subscribe(
      data=>{
        if(data!=null){
          console.log("user authenticated"+this.user)
          this.user=data;
          window.localStorage.setItem("user",JSON.stringify(this.user));
      
          this.toaster.success('Hello  WELCOME  '+ '  '+this.user.name);
          // this.check=true;
        this.route.navigate(['home'])
        }
        else
      {
        //this.toaster.success('Hello world!', 'Toastr fun!');
        this.toaster.error("Invalid Login Credentials","Login Error")
      //this.route.navigate(['user/signin'])
      console.log("Invalid credentials")
     // alert("Please enter valid credentials")
      
      }
        console.log("data received from login check"+data)

      },
      error=>{console.log("some error occured while sign in")}
    )

   
    
  }

}
