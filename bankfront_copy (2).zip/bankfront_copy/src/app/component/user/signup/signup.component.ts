import { Component, NgModule, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgserviceService } from 'src/app/ngservice.service';
import { User } from 'src/app/user';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user=new User()
  constructor(private ngservice:NgserviceService,
    private route:Router,private toaster:ToastrService) { }

  ngOnInit(): void {
  }

  addUserFormSubmit(addUserForm:any){
    console.log(this.user)
    this.ngservice.addNewUser(this.user).subscribe(
      data=>{this.toaster.success("User have been added Successfully")},
      error=>console.log(error)
    )

    this.route.navigate(['user/signin']);


  }
}
