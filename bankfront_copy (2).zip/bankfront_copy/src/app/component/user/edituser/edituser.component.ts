import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { NgserviceService } from 'src/app/ngservice.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {
user=new User();
selectId:any;
  constructor(private routs:ActivatedRoute,
    private _service:NgserviceService,private route:Router) { }

  ngOnInit(): void {
    this.routs.paramMap.subscribe(paramMap=>{
      this.selectId=paramMap.get('id');
      console.log(this.selectId);
    })

    //find user by id 
    this._service.getUserById(this.selectId).subscribe(
      data=>{this.user=data},
      error=>{console.log("error in fetching user by id")}
    )
    console.log(this.user.name)
  }

  editUserFormSubmit(editUserForm:any){
    this._service.updateUser(this.user,this.selectId).subscribe(
      data=>{console.log("user updated ");
      },
      //error=>console.log("error occured while updatin user")
    )
    this.route.navigate(['/user/listOfUsers']);
   // location.reload();
    
  }

}
