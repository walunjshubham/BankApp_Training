import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { Account } from './account';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class NgserviceService {

  constructor(private _client:HttpClient) { }

  //to add user
 
  addNewUser(user:User):Observable<any>{
    return this._client.post<any>("http://localhost:9090/user/addUser",user)

  }

  getListOfUsers():Observable<any>{
    return this._client.get<any>("http://localhost:9090/user/allUsers")
  }

  getUserById(selectId:number):Observable<any>{
  return this._client.get<any>("http://localhost:9090/user/getUser/"+selectId);
  }

  updateUser(user:User,id:number):Observable<any>{
    return this._client.put<any>("http://localhost:9090/user/updateUser/"+id,user);
  }

  getAccountListByUserID(id:number):Observable<any>{
   return this._client.get<any>("http://localhost:9090/account/getAccountByUserId/"+id);
  }

  deleteUserById(userId:number):Observable<any>{
    return this._client.delete<any>("http://localhost:9090/user/deleteUser/"+userId);
  }

  deleteAccountById(accountId:any):Observable<any>{
    return this._client.delete<any>("http://localhost:9090/account/deleteAccount/"+accountId);
  }
  
  updateAccountById(accountId:bigint,acc:Account):Observable<any>{
    return this._client.put<any>("http://localhost:9090/account/updateAccount/"+accountId,acc);
  }

  getAccountById(accountId:bigint):Observable<any>{
    return this._client.get<any>("http://localhost:9090/account/getAcc/"+accountId)
  }

  addAccount(account:any):Observable<any>{
    return this._client.post("http://localhost:9090/account/addAccount",account);
  }

  loginCheck(user:User):Observable<any>{
    return this._client.post("http://localhost:9090/user/loginCheck",user);

  }

}
