export class User{
    // user_ID!: number;
    // name!: string;
    // email_ID!: string;
    // password!:String
    // mobile_number!: number;
    // secondary_Mobile!: number;
    // dob!: Date;
    // gender!: string;




    user_ID!: number;
    name!: string;
    email_ID!: string;
    password!:String
    mobile_Number!: number;
    secondary_Mobile!: number;
    dob!: Date;
    gender!: string;
}

// int id,String name,@Email String email_ID,
// 			String password,@Pattern(regexp = "^[0-9]{10}$") String mobile_number,
// 			@Pattern(regexp = "^[0-9]{10}$") String secondary_Mobile, String dOB,
// 			char gender, List<Account> account