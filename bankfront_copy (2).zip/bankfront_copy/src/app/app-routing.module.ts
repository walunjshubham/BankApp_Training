import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountComponent } from './component/account/account.component';
import { AddAccountComponent } from './component/account/add-account/add-account.component';
import { EditAccountComponent } from './component/account/edit-account/edit-account.component';
import { ListOfAccountsComponent } from './component/account/list-of-accounts/list-of-accounts.component';
import { HomeComponent } from './component/home/home.component';
import { EdituserComponent } from './component/user/edituser/edituser.component';
import { ListOfUsersComponent } from './component/user/list-of-users/list-of-users.component';
import { SigninComponent } from './component/user/signin/signin.component';
import { SignupComponent } from './component/user/signup/signup.component';
import { UserComponent } from './component/user/user.component';

const routes: Routes = [
  {path:'' , component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'user',component:UserComponent,
  children:[
    {path:'editUser/:id',component:EdituserComponent},
  {path:'signin',component:SigninComponent},
  {path:'signup',component:SignupComponent},
  {path:'listOfUsers',component:ListOfUsersComponent}

]},
  {path:'account',component:AccountComponent,
children:[
  {path:'listOfAccounts/:userId',component:ListOfAccountsComponent},
  {path:'addAccount/:user_ID',component:AddAccountComponent},
  {path:'editAccount/:accountId',component:EditAccountComponent}

]

}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
