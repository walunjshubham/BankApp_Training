import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { UserComponent } from './component/user/user.component';
import { SigninComponent } from './component/user/signin/signin.component';
import { SignupComponent } from './component/user/signup/signup.component';
import { AccountComponent } from './component/account/account.component';
import { HeaderComponent } from './component/header/header.component';
import { FooterComponent } from './component/footer/footer.component';
import { ListOfUsersComponent } from './component/user/list-of-users/list-of-users.component';

import { EdituserComponent } from './component/user/edituser/edituser.component';
import { ListOfAccountsComponent } from './component/account/list-of-accounts/list-of-accounts.component';
import { AddAccountComponent } from './component/account/add-account/add-account.component';
import { EditAccountComponent } from './component/account/edit-account/edit-account.component';
import { SignOutComponent } from './component/user/sign-out/sign-out.component';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UserComponent,
    SigninComponent,
    SignupComponent,
    AccountComponent,
    HeaderComponent,
    FooterComponent,
    ListOfUsersComponent,
    
    EdituserComponent,
         ListOfAccountsComponent,
         AddAccountComponent,
         EditAccountComponent,
         SignOutComponent,
       
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ToastrModule.forRoot({
      timeOut: 2000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
    })  ,
    BrowserAnimationsModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
