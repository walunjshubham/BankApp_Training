package com.bank.project.service.serviceImpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.constraints.Pattern;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;

import com.bank.project.customException.NoAccountFoundException;
import com.bank.project.entity.Account;
import com.bank.project.entity.User;
import com.bank.project.repository.AccountRepository;
import com.bank.project.repository.UserRepository;


@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
@DisplayName("AccountServiceImpl Test")
class AccountServiceImplTest {

	@Autowired
	AccountServiceImpl aservice;

	@Autowired
	UserServiceImpl uservice;

	@MockBean
	AccountRepository arepo;

	@MockBean
	UserRepository urepo;

	private Account accountforTest;
	private Optional<Account> accountforTestOptional;
	private User userforTest;

	public AccountServiceImplTest() throws ParseException {
		accountforTest=new Account(1000000000,"HDFCbank",'S',50690);
		accountforTestOptional=Optional.of(new Account(1000000000,"HDFCbank",'S',50690));
		userforTest =new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null);
	}

	@Test
	@Order(2)
	void testGetAll() {
		List<Account> al=new ArrayList<>();
		al.add(accountforTest);
		when(arepo.findAll()).thenReturn(al);
		assertEquals(1, aservice.getAll().size());
	}

	@Test
	@Order(3)
	void testGetAccountById() {
		when(arepo.findById(1000000000L)).thenReturn(accountforTestOptional);
		assertEquals(accountforTest, aservice.getAccountById(1000000000));
	}


	@Test
	@Order(1)
	void testAddAccount(){
		accountforTest.setUser(userforTest);
		Optional<User> userforTestOptional=Optional.of(userforTest);
		when(urepo.findById(1)).thenReturn( userforTestOptional);
		assertEquals(userforTest, uservice.getUserById(1));

		when(arepo.save(accountforTest)).thenReturn(accountforTest);
		assertThat(aservice.addAccount(accountforTest)).isEqualTo(accountforTest);
	}

	@Test
	@Order(5)
	void testUpdateAccount() {
		accountforTest.setAccount_Balance(99999);
		accountforTest.setUser(userforTest);
		//long account_id,String branch_Name, char account_type, double account_balance, User user);
		when(arepo.updateAccountByID(1000000000L,"HDFCbank",'S',99999, userforTest)).thenReturn(1);
		assertEquals(1, aservice.updateAccount(accountforTest, 1000000000L));

	}

	@Test
	@Order(6)
	void testDeleteAccountById() {
		when(arepo.findById(1000000000L)).thenReturn(accountforTestOptional);
		assertEquals(accountforTest,arepo.findById(1000000000L).get() );
		aservice.deleteAccountById(1000000000);
		verify(arepo, times(1)).deleteById(1000000000L);
	}

	@Test
	@Order(4)
	void testGetAccountsByUserId() {
		when(arepo.getAccountsByUserId(1000000000)).thenReturn(Stream.of(new Account(1000000000,
				"HDFCbank",'S',50690)).collect(Collectors.toList()));
		assertEquals(1, aservice.getAccountsByUserId(1000000000).size());
	}
}
