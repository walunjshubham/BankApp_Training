package com.bank.project.service.serviceImpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.text.ParseException;
import java.util.Base64;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import com.bank.project.entity.User;
import com.bank.project.repository.UserRepository;


@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class UserServiceImplTest 
{

	@Autowired
	UserServiceImpl uservice;

	@MockBean
	UserRepository urepo;

	private User userforTest;
	private Optional<User> userforTestOptional;
	
	public UserServiceImplTest() throws ParseException {

		userforTest =new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null);

		userforTestOptional=Optional.of(new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null));
	}

	@Test
	@Order(1)
	void testSave() throws ParseException {

		when(urepo.save(userforTest)).thenReturn(userforTest);
		assertEquals(userforTest, uservice.save(userforTest));
	}

	@Test
	public void testGetUserById() throws ParseException {

		when(urepo.findById(1)).thenReturn(userforTestOptional);
		assertEquals(userforTest, uservice.getUserById(1));
	}

	@Test
	void testGetAll() throws ParseException
	{

		urepo.save(userforTest);
		when(urepo.findAll()).thenReturn(Stream.of(new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null)).collect(Collectors.toList()));
		assertEquals(1, uservice.getAll().size());
	}

	@Test
	public void testDeleteByID() throws ParseException {
		//when(urepo.deleteById(1))
		when(urepo.findById(1)).thenReturn(userforTestOptional);
		assertEquals(userforTestOptional, urepo.findById(1));
		uservice.DeleteByID(1);
		
		verify(urepo,times(1)).deleteById(1);
	}

	@Test
	void testUpdateUser() throws ParseException {
		User uUpdate=new User(1,"WALUNJ","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'F', null);

		when(urepo.findById(1)).thenReturn(userforTestOptional);
		assertEquals(userforTestOptional, urepo.findById(1));

		when(urepo.updateUserByID(1, uUpdate.getName(), uUpdate.getEmail_ID(), uUpdate.getMobile_Number(),
				uUpdate.getSecondary_Mobile(), uUpdate.getDOB(),uUpdate.getGender())).thenReturn(1);
		assertEquals(1, uservice.updateUser(uUpdate, 1));
	}

	@Test
	void testLogInCheck() throws ParseException {
		User u=new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null);
		String encodedPwd=Base64.getEncoder().encodeToString(u.getPassword().getBytes());
		u.setPassword(encodedPwd);

		when(urepo.loginCredentialsCheck(u.getEmail_ID(), u.getPassword())).thenReturn(u);
		assertEquals(u, uservice.logInCheck(userforTest));

	}

}
