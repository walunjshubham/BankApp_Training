package com.bank.project.entity;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


@DisplayName("UserEntityTest")
class UserTest {
	List<Account> al=new ArrayList<>();
	
	User u=new User();
	
	@Test
	void testGetName() {
		u.setName("Shubham");
		String exp="Shubham";
		  assertThat(exp).isEqualTo(u.getName());
	}

	@Test
	void testGetEmail_ID() {
		u.setEmail_ID("shubhamwalunj25@gmail.com");
		String exp="shubhamwalunj25@gmail.com";
		assertEquals(exp,u.getEmail_ID());
	}
		
	

	@Test
	void testGetPassword() {
		u.setPassword("Shubham");
		String exp="Shubham";
		assertThat(exp).isEqualTo(u.getPassword());
	}

	@Test
	void testGetMobile_number() {
		u.setMobile_Number("7387986939");
		String exp="7387986939";
		assertThat(exp).isEqualTo(u.getMobile_Number());
	}

	@Test
	void testGetGender() {
		u.setGender('m');
		char exp='m';
		assertThat(exp).isEqualTo(u.getGender());
		//assertThat(u.getGender()).withFailMessage("Gender not should be m/M or f/F");
	}

	@Test
	void testGetDOB() throws ParseException {
		Date d=new Date();
		String s="2022-12-11";
		
		 d= new Date(new SimpleDateFormat("yyyy-mm-dd").parse(s).getDate());
		 u.setDOB(d);
		 
			
	}

	@Test
	void testGetAccount() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetUser_ID() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetName() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetEmail_ID() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetPassword() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetMobile_number() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetSecondary_Mobile() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetGender() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetDOB() {
		//fail("Not yet implemented");
	}

	@Test
	void testSetAccount() {
		//fail("Not yet implemented");
	}

}
