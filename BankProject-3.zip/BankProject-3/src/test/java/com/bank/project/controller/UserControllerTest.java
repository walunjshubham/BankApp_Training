package com.bank.project.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bank.project.entity.User;
import com.bank.project.repository.UserRepository;
import com.bank.project.service.serviceImpl.UserServiceImpl;
import com.bank.project.service.serviceImpl.UserServiceImplTest;
@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class UserControllerTest {

	@MockBean
	UserRepository urepo;

	@MockBean
	User user;

	@Autowired
	UserController uc;

	private User userforTest;
	private List<User> list;
	private ResponseEntity<User> responseEntity;
	public UserControllerTest() throws ParseException {
		userforTest =new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null);

		list=new ArrayList<>();
		list.add(userforTest);

		responseEntity =
				ResponseEntity.status(HttpStatus.OK).body(userforTest);
	}

	@Test
	
	void testGetAllUsersList() throws ParseException {

		when(urepo.findAll()).thenReturn(Stream.of(new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null)).collect(Collectors.toList()));
		assertEquals(1,uc.getAllUsersList().getBody().size());
		assertThat(responseEntity).isNotNull();
		assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(list.size()).isEqualTo(1);
	}

	@Test
	@Order(2)
	void testGetUserById() {
		when(urepo.findById(1)).thenReturn(Optional.of(userforTest));
		assertEquals(responseEntity, uc.getUserById(1));
		assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	@Order(1)
	void testSaveUser() {
		when(urepo.save(userforTest)).thenReturn(userforTest);
		ResponseEntity< String> responseBySaveUser=new ResponseEntity<String>("User has been added successfully",HttpStatus.CREATED);
		assertThat(uc.saveUser(userforTest)).isEqualTo(responseBySaveUser);

	}

	@Test
	@Order(5)
	void testDeleteUserById() throws ParseException {
		when(urepo.findById(1)).thenReturn(Optional.of(userforTest));
		ResponseEntity< String> responseBySaveUser=new ResponseEntity<String>("User has been deleted successfully",HttpStatus.OK);
		assertThat(uc.deleteUserById(1)).isEqualTo(responseBySaveUser);
	}

	@Test
	@Order(3)
	void testUpdateUser() {
		ResponseEntity< String> responseBySaveUser=new ResponseEntity<String>("User updated",HttpStatus.OK);
		when(urepo.findById(1)).thenReturn(Optional.of(userforTest));
		userforTest.setName("Akshay");
		assertEquals(responseBySaveUser,uc.updateUser(1, userforTest));
	}

	@Test
	@Order(4)
	void testLogInCheckOfUser() throws ParseException {
		User u=new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null);
		String encodedPwd=Base64.getEncoder().encodeToString(u.getPassword().getBytes());
		u.setPassword(encodedPwd);
		when(urepo.loginCredentialsCheck(u.getEmail_ID(), u.getPassword())).thenReturn(u);
		assertEquals(u, uc.logInCheckOfUser(userforTest));

	}

}
