package com.bank.project.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bank.project.DTO.AccountDTO;
import com.bank.project.entity.Account;
import com.bank.project.entity.User;
import com.bank.project.repository.AccountRepository;
import com.bank.project.repository.UserRepository;
import com.bank.project.service.serviceImpl.AccountServiceImpl;

@SpringBootTest
class AccountControllerTest {

	@MockBean
	AccountRepository arepo;

	@MockBean
	UserRepository urepo;

	@Autowired
	AccountController ac;

	@Autowired
	AccountServiceImpl aService;

	private Account accountForTest;
	private User userforTest;

	public AccountControllerTest() throws ParseException {
		accountForTest=new Account(1000000000,"HDFCbank",'S',50690);
		userforTest =new User(1,"shubham","shubham12@gmail.com", "shubham123",
				"8899889988", "9890044186", "2022-12-11", 'M', null);

	}

	@Test
	void testGetAllAccounts(){
		when(arepo.findAll()).thenReturn(Stream.of(new Account(1000000000,"HDFCbank",'S'
				,50690)).collect(Collectors.toList()));
		assertEquals(1, ac.getAllAccounts().size());

	}

	@Test
	void testGetAccountById() {
		when(arepo.findById(1000000000L)).thenReturn(Optional.of(accountForTest));
		assertEquals(accountForTest, ac.getAccountById(1000000000L));
	}

	@Test
	void testGetAccountByUserId() {
		List<Account> list=new ArrayList<>();
		list.add(accountForTest);
		when(arepo.getAccountsByUserId(1)).thenReturn(list);
		assertEquals(list, ac.getAccountByUserId(1));
	}

	@Test
	void testAddAccount() throws UnsupportedEncodingException{
//		ResponseEntity<String> responseTest= new ResponseEntity<String>("Account has been added successFully",HttpStatus.CREATED);
//		AccountDTO dto=new AccountDTO(1000000000,"HDFCbank",'S',50690);
//		dto.setUser_ID(1);
//		when(urepo.findById(dto.getUser_ID())).thenReturn(Optional.of(userforTest));
//		accountForTest.setUser(userforTest);
//		when(arepo.save(accountForTest)).thenReturn(accountForTest);
//		assertThat(ac.addAccount(dto)).isEqualTo(responseTest);

	}

	@Test
	void testUpdateAccount() {
		accountForTest.setAccount_Type('C');
		when(arepo.updateAccountByID(1000000000,"HDFCbank",'C'
				,50690, userforTest)).thenReturn(1);
		ResponseEntity<String> responseTest=new ResponseEntity<String>("Account update successfully",HttpStatus.OK);
		assertEquals(1, ac.updateAccount(1000000000L, accountForTest));

	}

	@Test
	void testDeleteAccount() {
		when(arepo.findById((long) 1000000000)).thenReturn(Optional.of(accountForTest));
		ResponseEntity<String> responseTest =new ResponseEntity<String>("Account deleted successfully",HttpStatus.OK);
		assertThat(ac.deleteAccount(1000000000)).isEqualTo(responseTest);
	}

}
