package com.bank.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(BankProject1Application.class, args);
	}

}
