package com.bank.project.service.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.bank.project.customException.EmptyInputException;
import com.bank.project.customException.NoAccountFoundException;
import com.bank.project.customException.NoUsersFound;
import com.bank.project.entity.Account;
import com.bank.project.entity.User;
import com.bank.project.repository.AccountRepository;
import com.bank.project.repository.UserRepository;
import com.bank.project.service.AccountServices;



@Service
public class AccountServiceImpl implements AccountServices
{
	@Autowired
	AccountRepository arepo;
	@Autowired
	UserRepository urepo;
	@Autowired
	UserServiceImpl uservice;

	@Override
	public List<Account> getAll()
	{
		List<Account> list=arepo.findAll();
		if(list.isEmpty())
			throw new NoAccountFoundException();
		else
			return list;
	}

	@Override
	public Account getAccountById(long account_id)
	{
		Account ac=arepo.findById(account_id).get();
		if(ac!=null)
			return ac;
		else
			throw new NoAccountFoundException(HttpStatus.NOT_FOUND,"No account found");
	}
	
	@Override
	public Account addAccount(Account account)
	{
		User u=uservice.getUserById(account.getUser().getUser_ID());
		if(account.getBranch_Name().isEmpty())
			throw new EmptyInputException();
		else
			return arepo.save(account);

	}

	@Override
	public int updateAccount(Account account, long id) 
	{
		if(arepo.findById(id)!=null) 
		{
			return arepo.updateAccountByID(id,account.getBranch_Name(), account.getAccount_Type(),
					account.getAccount_Balance(),account.getUser());
		}
		else
			throw new NoAccountFoundException();
	}

	@Override
	public void deleteAccountById(long id) 
	{
		if(arepo.findById(id)!=null) 
		{
			arepo.deleteById(id);
		}
		else
			throw new NoAccountFoundException();
	}

	@Override
	public List<Account> getAccountsByUserId(int user_id) 
	{
	
		List<Account> list=arepo.getAccountsByUserId(user_id);
		if(list!=null)
			return list;
		else
			throw new NoAccountFoundException();
	}


}
