package com.bank.project.service;

import java.util.List;

import com.bank.project.entity.Account;

public interface AccountServices 
{
	public List<Account> getAll();
	
	public Account getAccountById(long account_id);
	
	public Account addAccount(Account account);
	
	public int updateAccount(Account account, long id);
	
	public void deleteAccountById(long id) ;
	
	public List<Account> getAccountsByUserId(int user_id);

}
