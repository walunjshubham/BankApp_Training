package com.bank.project.DTO;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountDTO {
/*
    account_id!:bigint;
    branch_Name!: string;
    account_type!: number;
    account_balance!: number;
    user_ID!:number;
    */
	
	private long account_Id;
	private String branch_Name;
	private char account_Type;
	private double account_Balance;
	private int user_ID;
	

	public AccountDTO() {

	}
	
	public AccountDTO(long account_id,String branch_Name, char account_type, double account_balance) {
		super();
		this.account_Id = account_id;
		this.branch_Name = branch_Name;
		this.account_Type = account_type;
		this.account_Balance = account_balance;
	}
	
}
