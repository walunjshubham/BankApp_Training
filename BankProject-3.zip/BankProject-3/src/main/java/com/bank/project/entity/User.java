package com.bank.project.entity;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;


@Entity
@Table(name="User")
@Data
public class User 
{
//	-- User_ID -- Primary Key -- numeric(5)
//	-- Name   -- 40 Chars
//	-- Email_ID   -- 100 cars
//	-- Mobile number -- 10 char
//	-- Secondary _Mobile -- 10 char
//	-- DOB --String format"DD-MMM-YYYY"
//	-- Gender -- (M/F) -- single Char

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int user_ID;
	@Column
	@NotNull(message = "Name should not be null")
	@Size(max = 40,message = "Name should not more than 40 characters")
	String name;
	@Column(unique = true)
	@Email(message = "Invalid email Address")
	@NotBlank(message = "Invalid email Address")
	@Size(max = 100,message = "Email should not more than 100 characters")
	String email_ID;
	@NotNull(message = "password should ot be blank")
	//@Size(min = 6,max = 15,message = "6 to 15 character password needed")
	String password;
	@Pattern(regexp = "^[0-9]{10}$",message = "Invalid mobile number")
	String mobile_Number;
	@Pattern(regexp = "^[0-9]{10}$",message = "Invalid secondary mobile number")
	String secondary_Mobile;
	@Column
	//@Pattern(regexp = "^[mMFf][1]$",message = "Gender should be m/M or f/F")
	char gender;
	@Column
	@Temporal(TemporalType.DATE)
	Date dOB;
	
	@JsonIgnore
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
	@Column(nullable = true)
	List<Account> account;
	
	public User() {
		super();
	}

	public User(String name, String email_ID, String password,String mobile_Number,
			String secondary_Mobile, String dOB,
			char gender, List<Account> account) throws ParseException {
		super();
		this.name = name;
		this.email_ID = email_ID;
		this.mobile_Number = mobile_Number;
		this.secondary_Mobile = secondary_Mobile;
		this.dOB = new Date(new SimpleDateFormat("yyyy-mm-dd").parse(dOB).getDate());
		this.gender = gender;
		this.account = account;
		this.password=password;
	}

	public User(int id,String name,@Email String email_ID,
			String password,@Pattern(regexp = "^[0-9]{10}$") String mobile_Number,
			@Pattern(regexp = "^[0-9]{10}$") String secondary_Mobile, String dOB,
			char gender, List<Account> account) throws ParseException {
		super();
		this.user_ID = id;
		this.name = name;
		this.email_ID = email_ID;
		this.mobile_Number = mobile_Number;
		this.secondary_Mobile = secondary_Mobile;
		this.dOB = new Date(new SimpleDateFormat("yyyy-mm-dd").parse(dOB).getDate());
		this.gender = gender;
		this.account = account;
		this.password=password;
	}
	

}