package com.bank.project.controllerAdvice;

import java.util.NoSuchElementException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.bank.project.customException.EmptyInputException;
import com.bank.project.customException.NoAccountFoundException;
import com.bank.project.customException.NoUsersFound;

@org.springframework.web.bind.annotation.ControllerAdvice
public class ControllerAdvice extends ResponseEntityExceptionHandler
{

	//system exception
	
	  @ExceptionHandler(NoSuchElementException.class) public ResponseEntity<?>
	  noSuchElementException(NoSuchElementException noSuchElementException) {
	  return new ResponseEntity<String>("No such ELEMENT found",
	  HttpStatus.NOT_FOUND);
	  }
	 
	
	//custom exception
	@ExceptionHandler(EmptyInputException.class)
	public ResponseEntity<?> emptyInputException(EmptyInputException emptyInputException)
	{
		return new ResponseEntity<String>("Empty input,please provide all fields/Information",
				HttpStatus.NOT_ACCEPTABLE);
		
	}
	
	//nousers in db custom exception
	//custom exception
	@ExceptionHandler(NoUsersFound.class)
	public ResponseEntity<?> noUsersFound(NoUsersFound noUsersFound)
	{
		return new ResponseEntity<String>("No users Found in database",
				HttpStatus.NOT_FOUND);
		
	}
	
	//NoAccountFoundException
	@ExceptionHandler(NoAccountFoundException.class)
	public ResponseEntity<?> noAccountFoundException(NoAccountFoundException noAccountFoundException)
	{
		return new ResponseEntity<String>("No Account Found in database",
				HttpStatus.NOT_FOUND);
		
	}
	
	
	//request method invalid exception 
	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		// TODO Auto-generated method stub
		//return super.handleHttpRequestMethodNotSupported(ex, headers, status, request);
		return new ResponseEntity<Object>("Please check http request method",HttpStatus.NOT_FOUND);
	}
	
	
	
	
}
