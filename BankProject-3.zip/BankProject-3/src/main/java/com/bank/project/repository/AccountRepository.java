package com.bank.project.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bank.project.entity.Account;
import com.bank.project.entity.User;

@Transactional
@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {



	//@Modifying
	@Query(value="select * FROM account where user_id=?1",nativeQuery = true)
	public List<Account> getAccountsByUserId(int user_ID);
	
//	@Modifying
//    @Query(value = " select * from account where user_id=?1", nativeQuery = true)
//    public List<Account> getAccountByUserID(int userID);
	
	@Modifying
	@Query(value=" delete from account where account_id=?1",nativeQuery = true) 
	public int deleteUserById(int User_ID);


	@Modifying
	@Query(value=" update account set account_balance=?4,account_type=?3,branch_name=?2,user_id=?5 where account_id=?1 ",nativeQuery = true)
	public int updateAccountByID(long account_id,String branch_Name, char account_type, double account_balance, User user);

}
