package com.bank.project.service;

import java.util.List;

import com.bank.project.entity.User;

public interface UserServices 
{
	public User save(User user);
	
	public User getUserById(int User_ID);
	
	public List<User> getAll();
	
	public void DeleteByID(int User_ID);
	
	public int updateUser(User user,int id);
	
	public User logInCheck(User user);
	

}
