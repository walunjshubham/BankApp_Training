package com.bank.project.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bank.project.entity.Account;
import com.bank.project.entity.User;

@Transactional
@Repository
public interface UserRepository extends JpaRepository<User, Integer>
{
	
	@Query(value=" select * from user where email_id=?1 && password=?2",nativeQuery = true)
	public User loginCredentialsCheck(String Email_ID, String Password);
	
	@Modifying
	@Query(value=" update user set name=?2,email_ID=?3,mobile_Number=?4,secondary_Mobile=?5,dOB=?6,gender=?7 where user_ID=?1 ",nativeQuery = true)
	public int updateUserByID(int id,String name, String email_ID, String mobile_number, String secondary_Mobile, Date dob,
			char gender);

}
