package com.bank.project.entity;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table
@Getter
@Setter
public class Account {
//	-- Account_id -- Numeric(10) double
//	-- User_ID -- foreign key
//	-- Branch_name -- 40 chars
//	-- Account_type -- (S-savings/C-current) 1 
//	-- Account_balance -- numeric (10,2)
	
	/*
	ccount_Id: 1000000000, 
	branch_Name: 'sbi', 
	account_Type: 'C',
	 account_Balance: 8888888, 
	 user
	 */

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long account_Id;

	@Column
	@Pattern(regexp = "^[a-zA-Z]{2,40}$")
	@NotBlank(message = "Please enter branch name")
	private String branch_Name;

	@Column
	//@Pattern(regexp = "^[a-zA-z]{1}$")
	//@NotBlank(message = "Please enter Account Type S/C")
	private char account_Type;

	@Column
	private double account_Balance;

	//@JsonIgnore
	@ManyToOne()
	@JoinColumn(name = "User_ID",nullable = true)
	private User user;

	public Account() {

	}
	public Account(long account_Id,@Pattern(regexp = "^[a-zA-z]{}$") String branch_Name, char account_Type, double account_Balance) {
		super();
		this.account_Id = account_Id;
		this.branch_Name = branch_Name;
		this.account_Type = account_Type;
		this.account_Balance = account_Balance;
	}

	public Account(@Pattern(regexp = "^[a-zA-Z]{2,40}$") String branch_Name, 
			char account_Type, double account_Balance,User u) {
		super();
		this.branch_Name = branch_Name;
		this.account_Type = account_Type;
		this.account_Balance = account_Balance;
		this.user=u;
	}

}
