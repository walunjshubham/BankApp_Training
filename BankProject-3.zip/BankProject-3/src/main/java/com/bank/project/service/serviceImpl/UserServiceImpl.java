package com.bank.project.service.serviceImpl;

import java.util.Base64;
import java.util.List;

import java.util.Optional;
import java.util.Base64.Decoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bank.project.customException.EmptyInputException;
import com.bank.project.customException.NoUsersFound;
import com.bank.project.entity.Account;
import com.bank.project.entity.User;
import com.bank.project.repository.AccountRepository;
import com.bank.project.repository.UserRepository;
import com.bank.project.service.UserServices;


@Service
public class UserServiceImpl implements UserServices
{
	@Autowired
	UserRepository urepo;
	@Autowired
	AccountRepository arepo;

	//Encoder encoder = Base64.getEncoder();
	Decoder decoder=Base64.getDecoder();

	@Override
	public User save(User u) 
	{
		List<Account> arr=u.getAccount();
		//System.out.println(arr.toString());


		if(!(u.getName().isEmpty() || u.getName().length()==0))
		{		

			//User us=new User(u.getName(), u.getEmail_ID(), u.getPassword(),u.getMobile_number(), u.getSecondary_Mobile(), 
			//u.getDOB(),u.getGender(),arr);
			//u.setAccount(arr);
			return urepo.save(u);
		}
		else
			throw new EmptyInputException();
	}

	@Override
	public User getUserById(int User_ID)
	{
		User u=urepo.findById(User_ID).get();
		//System.out.println("finding user");
		//	byte[] decoded = decoder.decode(u.getPassword());
		//String decodedStr = new String(decoded);
		//System.out.println(decodedStr);
		//u.setPassword(decodedStr);

		if(u!=null)
			return u;
		else
			throw new NoUsersFound();
	}

	@Override
	public List<User> getAll()
	{
		List<User> all=urepo.findAll();
		for (User user : all) {
			//byte[] decoded = decoder.decode(user.getPassword());
			//String decodedStr = new String(decoded);
			//user.setPassword(decodedStr);
			//System.out.println(user.getPassword());

		}

		if(urepo.findAll().isEmpty())
			throw new NoUsersFound();
		else	
			return all;
	}

	@Override
	public void DeleteByID(int User_ID) 
	{
		User u=urepo.findById(User_ID).get();	//to avoid null check
		if(u!=null)
			urepo.deleteById(User_ID);
		else
			throw new NoUsersFound();
	}

	@Override
	public int updateUser(User user,int id) 
	{
		User ex=urepo.findById(id).get();
		if(ex==null) {
			throw new NoUsersFound();


		}
		else {
			/*
			  ex.setDOB(user.getDOB()); ex.setEmail_ID(user.getEmail_ID());
			  ex.setGender(user.getGender()); ex.setMobile_number(user.getMobile_number());
			  ex.setName(user.getName());
			  ex.setSecondary_Mobile(user.getSecondary_Mobile()); ex.setUser_ID(id);
			  urepo.save(ex);
			 */

			return urepo.updateUserByID(id,user.getName(),user.getEmail_ID(),user.getMobile_Number(),
					user.getSecondary_Mobile(),user.getDOB(),user.getGender());

		}

	}

	@Override
	public User logInCheck(User user) 
	{
		if(user.getEmail_ID().isEmpty() && user.getPassword().isEmpty())
			throw new EmptyInputException();
		else
		{
			String encodedPwd=Base64.getEncoder().encodeToString(user.getPassword().getBytes());
			user.setPassword(encodedPwd);
			//System.out.println(user.getEmail_ID()+" "+user.getPassword());
			User checkUser=urepo.loginCredentialsCheck(user.getEmail_ID(), user.getPassword());

			if( checkUser!=null)
			{
				return checkUser;
			}
			else	
				return null;
		}


	}
}
