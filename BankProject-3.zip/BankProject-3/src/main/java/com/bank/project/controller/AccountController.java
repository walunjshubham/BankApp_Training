package com.bank.project.controller;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bank.project.DTO.AccountDTO;
import com.bank.project.entity.Account;
import com.bank.project.entity.User;
import com.bank.project.service.serviceImpl.AccountServiceImpl;
import com.bank.project.service.serviceImpl.UserServiceImpl;



@CrossOrigin
@RestController
@RequestMapping("/account")
public class AccountController 
{
	@Autowired
	AccountServiceImpl aservice;
	@Autowired
	UserServiceImpl uservice;
	Decoder decoder=Base64.getDecoder();
	Encoder encoder=Base64.getEncoder();

	@GetMapping("/allAccounts")
	public List<Account> getAllAccounts()
	{
		List<Account> listOfAllAccounts = aservice.getAll();
		return listOfAllAccounts;
		//return new ResponseEntity<List<Account>>(listOfAllAccounts, HttpStatus.OK);

	}

	@GetMapping("/getAcc/{account_id}")
	public Account getAccountById(@PathVariable("account_id") long id)
	{
		Account ac=aservice.getAccountById(id);
		System.out.println(ac);
		return ac;
		//return new ResponseEntity<Account>(ac,HttpStatus.FOUND);
	}

	@GetMapping("/getAccountByUserId/{user_id}")
	public List<Account> getAccountByUserId(@PathVariable("user_id") int user_id)
	{
		System.out.println(user_id);
		List<Account> list=aservice.getAccountsByUserId(user_id);
		System.out.println(list.size()+" list"+list);
		return list;
		//return new ResponseEntity<List<Account> >(list,HttpStatus.FOUND);
	}

	//public ResponseEntity<?> addAccount(@RequestBody Account account)
	@PostMapping("/addAccount")
	public ResponseEntity<?> addAccount(@RequestBody AccountDTO account) throws UnsupportedEncodingException
	{
		
		System.out.println("Accout tyep at dto ====="+account.getAccount_Type());
		User user=uservice.getUserById(account.getUser_ID());
		//System.out.println("User get by id in account controller"+user.getPassword());
		
		//byte[] bytes = user.getPassword().getBytes();
		//String encoded = Base64.getEncoder().encodeToString(user.getPassword().getBytes());
		//user.setPassword(encoded);

		//System.out.println(account.getUser_ID()+"   user id and user details "+user);
		//@Pattern(regexp = "^[a-zA-z]{}$") String branch_Name, 
		//char account_type, double account_balance) {

		Account addAccount=new Account(account.getBranch_Name(),account.getAccount_Type(),
				account.getAccount_Balance(),user);
		//System.out.println("new Account"+addAccount);
		System.out.println("Accout tyep at acc ====="+addAccount.getAccount_Type());

		if(account!=null) {
			Account ac=aservice.addAccount(addAccount);
			return new ResponseEntity<String>("Account has been added successFully",HttpStatus.CREATED);
		}else
			return null;
	}

	@PutMapping("/updateAccount/{id}")
	public ResponseEntity<?> updateAccount(@PathVariable ("id") long id,@RequestBody Account account)
	{
		//System.out.println("account name"+account.getAccount_balance());
		aservice.updateAccount(account,id);
		return new ResponseEntity<String>("Account update successfully",HttpStatus.OK);


	}

	@DeleteMapping("/deleteAccount/{id}")
	public ResponseEntity<?> deleteAccount(@PathVariable ("id") int id)
	{
		aservice.deleteAccountById(id);
		return new ResponseEntity<String>("Account deleted successfully",HttpStatus.OK);
	}
}
