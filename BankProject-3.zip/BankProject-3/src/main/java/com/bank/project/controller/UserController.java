package com.bank.project.controller;


import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bank.project.entity.User;

import com.bank.project.service.serviceImpl.UserServiceImpl;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController 
{
	@Autowired
	UserServiceImpl uservice;
	Encoder encoder = Base64.getEncoder();

	@GetMapping("/allUsers")
	public ResponseEntity<List<User>> getAllUsersList()
	{
		List<User> listOfAllAccounts = uservice.getAll();
		System.out.println(listOfAllAccounts);
		return new ResponseEntity<List<User>>(listOfAllAccounts, HttpStatus.OK);
	}

	@GetMapping("/getUser/{user_id}")
	public ResponseEntity<User> getUserById(@PathVariable("user_id") int user_id)
	{
		User user=uservice.getUserById(user_id);
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}

	@PostMapping("/addUser")
	public ResponseEntity<?> saveUser(@RequestBody User u) 
	{
		String encoded = encoder.encodeToString(u.getPassword().getBytes());
		u.setPassword(encoded);
		uservice.save(u);
		System.out.println(u.getMobile_Number());
		return new ResponseEntity<String>("User has been added successfully", HttpStatus.CREATED);
	}

	@DeleteMapping("/deleteUser/{User_ID}")
	public ResponseEntity<?> deleteUserById(@PathVariable("User_ID") int User_ID)
	{
		if(User_ID!=0) {
			uservice.DeleteByID(User_ID);
			return new ResponseEntity<String>("User has been deleted successfully", HttpStatus.OK);
		}
		else
			return new ResponseEntity<String>("Some error occurred while deleting user,please enter valid userID", HttpStatus.NON_AUTHORITATIVE_INFORMATION);
	}

	@PutMapping("/updateUser/{id}")
	public ResponseEntity<?> updateUser(@PathVariable ("id") int id,@RequestBody User user)
	{

		if(user!=null)
		{
			uservice.updateUser(user,id);
			return new ResponseEntity<String>("User updated", HttpStatus.OK);
		}
		else
			return new ResponseEntity<String>("User NOT updated", HttpStatus.NOT_ACCEPTABLE);
	}

	@PostMapping("/loginCheck")
	public User logInCheckOfUser(@RequestBody User user)
	{
		if(user!=null)
		{

			return uservice.logInCheck(user);
		}
		else
			return null;	
	}
}
