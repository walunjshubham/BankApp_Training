import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-comp',
  templateUrl: './text-comp.component.html',
  styleUrls: ['./text-comp.component.css']
})
export class TextcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
