import { Component, OnInit } from '@angular/core';
import { NgserviceService } from '../ngservice.service';
import { NgForm } from '@angular/forms';
import { User } from '../user';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  user = new User();
  

  constructor(private _service:NgserviceService,private router :Router, private toastr:ToastrService) { 
   
  }

  ngOnInit(): void {

  }

  addUserFormSubmit(addUserForm:any){
    if(this.user.gender == null)
      this.user.gender = "M"
    console.log("User : ",this.user);
    
    this._service.addNewUser(this.user).subscribe(data => {
      console.log("data : "+data);
      if (data != null) 
      {
        this.toastr.success("Successfully logged in", "Success");
        this.router.navigate(['/login']);
      } 
      else 
      {
        console.log("Sign up form error ...something is wrong filled");
        this.toastr.error("Invalid information filled", "Failure");
        this.router.navigate(['/register']);
      }
    });

  }

}

// this._service.addNewUser(this.user).subscribe(
//   data=>console.log("Data added successfully",this.user.dob),
//   error=>console.log("error occured")
// )
// console.log(addUserForm);
// this.router.navigate(['/login'])