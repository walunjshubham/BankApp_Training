import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-account-details',
  templateUrl: './edit-account-details.component.html',
  styleUrls: ['./edit-account-details.component.css']
})
export class EditAccountDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
