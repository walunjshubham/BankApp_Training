export class User{
    user_ID!: number;
    name!: string;
    email_ID!: string;
    mobile_number!: number;
    secondary_Mobile!: number;
    dob!: Date;
    gender!: string;
    password!: string;

    // constructor(userResponse:any){
    //     this.Name=userResponse.Name;
    //     this.Email_ID=userResponse.Email_ID;
    //     this.Mobile_number=userResponse.Mobile_number;
    //     this.Secondary_Mobile=userResponse.Secondary_Mobile;
    //     this.DOB=userResponse.DOB; 
    //     this.Gender=userResponse.Gender;
    // }
}