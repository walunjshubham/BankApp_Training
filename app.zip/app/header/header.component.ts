import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { User } from '../user';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  user = new  User();

  constructor(private router:Router,private toastr: ToastrService) { }

  ngOnInit(): void {
    let u:any = window.localStorage.getItem('userDetails');
    this.user = JSON.parse(u);
    
  }

  logoutUser(){
    console.log("localstorage is cleared")
    window.localStorage.clear();
    this.toastr.success("Successfully logged out", "Success");
    this.router.navigate(['/home'])
  }

}





