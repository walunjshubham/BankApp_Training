import { Component, OnInit } from '@angular/core';
import { NgserviceService } from '../ngservice.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-user-ls',
  templateUrl: './user-ls.component.html',
  styleUrls: ['./user-ls.component.css']
})
export class UserListComponent implements OnInit {
  CurrId : any ;
  user = new User();
  userData:any=[];

  constructor(private router: Router,private _service: NgserviceService) {
    let userData = this._service.fetchUserList().subscribe(data=>{
     this.userData=data;
    });
    console.log(userData);
    
   }

  ngOnInit(){
    
    let u:any = window.localStorage.getItem('userDetails');
    this.user = JSON.parse(u);
    

      if(this.user === null)
      { 
        alert("You have to login first as a User");
        this.router.navigate(['/login'])
      }

      else
      {
        this._service.fetchUserList().subscribe(
          data=>console.log("response received ",data),
          error=>console.log("exception occured")
        )
      }

      this.CurrId = this.user.user_ID;
      console.log("user : ", this.user , " CurrID : ", this.CurrId)

  }

  // btnClickEdit=() =>{
  //   this.router.navigate(['/editUser']);
  // }

  goToEditUser(id:number){
    console.log('ID : ',id,'  CurrID: ',this.CurrId);
    if(id === this.CurrId)
      this.router.navigate(['/editUser',this.CurrId]);
    else
      alert("You have to login with this credentials first")
  }

  goToDeleteUser(id:number){
    if(id === this.CurrId)
    {
      this._service.deletUserDetails(this.CurrId).subscribe(
        data=>console.log("response received"),
        error=>console.log("exception occured")
      )
      window.location.reload();
    }
    else
      alert("You have to login with this credentials first")
  }

  // btnDeleteClick(){
   
  //     this._service.deleteUser(this.user).subscribe(
  //       data=>console.log("data added successfully"),
  //       error=>console.log("error occured")
  //     )
 
  
  // }

  goToViewAccount(id:number)
  {
    console.log('id : ',id, ' currId :',this.CurrId);

    if(id === this.CurrId)
      this.router.navigate(['/viewAccount',this.CurrId]);
    else
      alert("You have to login with this credentials first")
  }
    //this.router.navigate(['/getUsers']);

  goToAddAccout(id:number)
  {
    console.log(" Id : "+id);
    if(id === this.CurrId)
      this.router.navigate(['/addAccount',this.CurrId]);
    else
      alert("You have to login with this credentials first")
  }
}


