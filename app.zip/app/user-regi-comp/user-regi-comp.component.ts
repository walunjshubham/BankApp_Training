import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-registration-component',
  templateUrl: './user-regi-comp.component.html',
  styleUrls: ['./user-regi-comp.component.css']
})
export class UserRegistrationComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
